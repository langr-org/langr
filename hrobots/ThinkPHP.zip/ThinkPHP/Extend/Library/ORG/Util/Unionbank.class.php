<?php
/**
 * 支付宝处理页面 
 */
class Unionbank {
	
	/**
	 * 构造函数
	 * @return Alipay
	 */
	public function Unionbank() {
		
	}

	/**
     * 生成支付代码
     * @param   array   $order      订单信息
     * @param   integer $style    显示样式
     * @return	string
     */
    public function unionbank_code($order, $style = 1)
    {
    	include_once("unionbank_config.php");
		$OrdId = $order['order_sn'];	//订单号
		$OrdAmt = number_format($order['order_amount'],2,'.','');//订单金额
		$GateId = intval($order['bank_type']);			         //银行代码
		
		$MerPriv  = $order['log_id']."-".$order['pay_type'];     //pay_type:支付的类型，0为订单，1为充值
		//加签
		$fp = fsockopen($npc_url, $npc_port, $errno, $errstr, 10);
		if (!$fp) {
			echo "$errstr ($errno)<br />\n";
		} else {
			
			$MsgData = $Version.$CmdId.$MerId.$OrdId.$OrdAmt.$CurCode.$Pid.$RetUrl.$MerPriv.$GateId.$UsrMp.$DivDetails.$PayUsrId.$BgRetUrl;
			$MsgData_len =strlen($MsgData);
			if($MsgData_len < 100 ){
				$MsgData_len = '00'.$MsgData_len;
			}
			elseif($MsgData_len < 1000 ){
				$MsgData_len = '0'.$MsgData_len;
			}

			$out = 'S'.$MerId.$MsgData_len.$MsgData;
			
			$out_len = strlen($out);
			if($out_len < 100 ){
				$out_len = '00'.$out_len;
			}
			elseif($out_len < 1000 ){
				$out_len = '0'.$out_len;
			}
			$out =$out_len.$out;

			//echo $MsgData_len;exit;
			//$out = '0021S87052400101234567890';
			
			fputs($fp, $out);
			$ChkValue ='';
			while (!feof($fp)) {
				$ChkValue .= fgets($fp, 128);
			}
			$ChkValue = substr($ChkValue, -256);
			fclose($fp);
			/* 手动提交表单 */
			if ($style == 1) {
				$form = '<form name="paysubmit" method="post" action="http://mas.chinapnr.com/gar/RecvMerchant.do">
					<input type=hidden name="ChkValue" value="'.$ChkValue.'">
					<input type=hidden name="Version" value="'.$Version.'">
					<input type=hidden name="CmdId" value="'.$CmdId.'">
					<input type=hidden name="MerId" value="'.$MerId.'">
					<input type=hidden name="OrdId" value="'.$OrdId.'">
					<input type=hidden name="OrdAmt" value="'.$OrdAmt.'">
					<input type=hidden name="CurCode" value="'.$CurCode.'">
					<input type=hidden name="Pid" value="'.$Pid.'">
					<input type=hidden name="RetUrl" value="'.$RetUrl.'">
					<input type=hidden name="BgRetUrl" value="'.$BgRetUrl.'">
					<input type=hidden name="MerPriv" value="'.$MerPriv.'">
					<input type=hidden name="GateId" value="'.$GateId.'">
					<input type=hidden name="UsrMp" value="'.$UsrMp.'">
					<input type=hidden name="DivDetails" value="'.$DivDetails.'">
					<input type=hidden name="PayUsrId" value="'.$PayUsrId .'">
					<input type="submit" name="Submit" id="paySubmitBtn" class="ui-button ui-button-morange" value="立即支付">
				</form>';
			} elseif ($style == 2) {
				$form = '<form name="paysubmit"  method="post" action="http://mas.chinapnr.com/gar/RecvMerchant.do">
					<input type=hidden name="ChkValue" value="'.$ChkValue.'">
					<input type=hidden name="Version" value="'.$Version.'">
					<input type=hidden name="CmdId" value="'.$CmdId.'">
					<input type=hidden name="MerId" value="'.$MerId.'">
					<input type=hidden name="OrdId" value="'.$OrdId.'">
					<input type=hidden name="OrdAmt" value="'.$OrdAmt.'">
					<input type=hidden name="CurCode" value="'.$CurCode.'">
					<input type=hidden name="Pid" value="'.$Pid.'">
					<input type=hidden name="RetUrl" value="'.$RetUrl.'">
					<input type=hidden name="BgRetUrl" value="'.$BgRetUrl.'">
					<input type=hidden name="MerPriv" value="'.$MerPriv.'">
					<input type=hidden name="GateId" value="'.$GateId.'">
					<input type=hidden name="UsrMp" value="'.$UsrMp.'">
					<input type=hidden name="DivDetails" value="'.$DivDetails.'">
					<input type=hidden name="PayUsrId" value="'.$PayUsrId .'">	
					<input type="submit" name="Submit" id="paySubmitBtn" class="top-upBtn" value="支付">
				</form>';		
				
				
			} elseif ($style == 3) {
				$form = '<form name="paysubmit"  method="post" action="http://mas.chinapnr.com/gar/RecvMerchant.do">
					<input type=hidden name="ChkValue" value="'.$ChkValue.'">
					<input type=hidden name="Version" value="'.$Version.'">
					<input type=hidden name="CmdId" value="'.$CmdId.'">
					<input type=hidden name="MerId" value="'.$MerId.'">
					<input type=hidden name="OrdId" value="'.$OrdId.'">
					<input type=hidden name="OrdAmt" value="'.$OrdAmt.'">
					<input type=hidden name="CurCode" value="'.$CurCode.'">
					<input type=hidden name="Pid" value="'.$Pid.'">
					<input type=hidden name="RetUrl" value="'.$RetUrl.'">
					<input type=hidden name="BgRetUrl" value="'.$BgRetUrl.'">
					<input type=hidden name="MerPriv" value="'.$MerPriv.'">
					<input type=hidden name="GateId" value="'.$GateId.'">
					<input type=hidden name="UsrMp" value="'.$UsrMp.'">
					<input type=hidden name="DivDetails" value="'.$DivDetails.'">
					<input type=hidden name="PayUsrId" value="'.$PayUsrId .'">	
				</form>';		
				$form.='<script type="text/javascript">document.forms[0].submit()</script>';
				
			}
			
			return $form;
		}
    }
    
    /**
     * 响应回调函数
     */
    public function respond() {
    	
		include_once("unionbank_config.php");
    	$CmdId = $_POST['CmdId'];			//消息类型
		$MerId = $_POST['MerId']; 	 		//商户号
		$RespCode = $_POST['RespCode']; 	//应答返回码
		$TrxId = $_POST['TrxId'];  			//钱管家交易唯一标识
		$OrdAmt = $_POST['OrdAmt']; 		//金额
		$CurCode = $_POST['CurCode']; 		//币种
		$Pid = $_POST['Pid'];  				//商品编号
		$OrdId = $_POST['OrdId'];  			//订单号
		$MerPriv = $_POST['MerPriv'];  		//商户私有域
		$RetType = $_POST['RetType'];  		//返回类型
		$DivDetails = $_POST['DivDetails']; //分账明细
		$GateId = $_POST['GateId'];  		//银行ID
		$ChkValue = $_POST['ChkValue']; 	//签名信息
		
		$fp = fsockopen($npc_url, $npc_port, $errno, $errstr, 10);
		if (!$fp) {
			return false;
		} else {
			
			$MsgData = $CmdId.$MerId.$RespCode.$TrxId.$OrdAmt.$CurCode.$Pid.$OrdId.$MerPriv.$RetType.$DivDetails.$GateId;
			 
			$MsgData_len =strlen($MsgData);
			if($MsgData_len < 100 ){
				$MsgData_len = '00'.$MsgData_len;
			}
			elseif($MsgData_len < 1000 ){
				$MsgData_len = '0'.$MsgData_len;
			}

			$out = 'V'.$MerId.$MsgData_len.$MsgData.$ChkValue;
			
			$out_len = strlen($out);
			if($out_len < 100 ){
				$out_len = '00'.$out_len;
			}
			elseif($out_len < 1000 ){
				$out_len = '0'.$out_len;
			}
			$out =$out_len.$out;
			

			//echo $MsgData_len;exit;
			//$out = '0021S87052400101234567890';
			fputs($fp, $out);

			$ChkValue ='';
			while (!feof($fp)) {
				$ChkValue .= fgets($fp, 128);
			}
			fclose($fp);
			//echo $ChkValue;
		}

		$SignData = $ChkValue;
		
		if($SignData == "0011V".$MerId."0000"){	
			if($RespCode == "000000"){
				$log_id = trim($MerPriv);
				$ar     = explode("-",$log_id);	//$ar[0]为支付 ID，$ar['1']为支付类型，0为定单，1为充值
				if (!check_money($ar['0'], $OrdAmt)) {
					
					return false;
				}
				
				order_paid($ar['0'], 2 ,'' ,$ar['1']);
				return true;
			}else{
				return false;
			}
			
		}else{
				return false;
		}
    }
    
	 /**
     * 响应回调函数
     */
    public function notify() {
    	
		$CmdId = $_POST['CmdId'];			//消息类型
		$MerId = $_POST['MerId']; 	 		//商户号
		$RespCode = $_POST['RespCode']; 	//应答返回码
		$TrxId = $_POST['TrxId'];  			//钱管家交易唯一标识
		$OrdAmt = $_POST['OrdAmt']; 		//金额
		$CurCode = $_POST['CurCode']; 		//币种
		$Pid = $_POST['Pid'];  				//商品编号
		$OrdId = $_POST['OrdId'];  			//订单号
		$MerPriv = $_POST['MerPriv'];  		//商户私有域
		$RetType = $_POST['RetType'];  		//返回类型
		$DivDetails = $_POST['DivDetails']; //分账明细
		$GateId = $_POST['GateId'];  		//银行ID
		$ChkValue = $_POST['ChkValue']; 	//签名信息
		
		$fp = fsockopen($npc_url, $npc_port, $errno, $errstr, 10);
		if (!$fp) {
			return false;
		} else {
			
			$MsgData = $CmdId.$MerId.$RespCode.$TrxId.$OrdAmt.$CurCode.$Pid.$OrdId.$MerPriv.$RetType.$DivDetails.$GateId;
			 
			$MsgData_len =strlen($MsgData);
			if($MsgData_len < 100 ){
				$MsgData_len = '00'.$MsgData_len;
			}
			elseif($MsgData_len < 1000 ){
				$MsgData_len = '0'.$MsgData_len;
			}

			$out = 'V'.$MerId.$MsgData_len.$MsgData.$ChkValue;
			
			$out_len = strlen($out);
			if($out_len < 100 ){
				$out_len = '00'.$out_len;
			}
			elseif($out_len < 1000 ){
				$out_len = '0'.$out_len;
			}
			$out =$out_len.$out;

			fputs($fp, $out);

			$ChkValue ='';
			while (!feof($fp)) {
				$ChkValue .= fgets($fp, 128);
			}
			fclose($fp);
			
		}
		$SignData = $ChkValue;
		
		if($SignData == "0011V".$MerId."0000"){	
			if($RespCode == "000000"){
				$log_id = trim($MerPriv);
				$ar     = explode("-",$log_id);	//$ar[0]为支付 ID，$ar['1']为支付类型，0为定单，1为充值
				if (!check_money($ar['0'], $OrdAmt)) {
					return false;
				}
				order_paid($ar['0'], 2 ,'' ,$ar['1']);
				return true;
			}else{
				return false;
			}
			
		}else{
				return false;
		}
    }
}




