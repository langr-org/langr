<?php
	$Version = 10;
	$CmdId = "Buy";
	$MerId = 871771;
	$CurCode = "RMB";
	$Pid = '0001';
	$RetUrl = C('WEB_HOST') . '/Pay_Unionbankback' ;
	$BgRetUrl = C('WEB_HOST') . '/Pay_Unionbanknotify';
	$MerPriv = 'pcb';
	$UsrMp = 18680392069;
	$DivDetails = '';
	$PayUsrId = '';
	//加签
	$npc_url = '172.168.16.48';
	$npc_port = 8878;


