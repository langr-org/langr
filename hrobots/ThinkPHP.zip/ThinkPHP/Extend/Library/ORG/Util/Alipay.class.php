<?php
/**
 * 支付宝处理页面 
 */
class Alipay {
	
	/**
	 * 构造函数
	 * @return Alipay
	 */
	public function Alipay() {
		
	}

	/**
     * 生成支付代码
     * @param   array   $order      订单信息
     * @param   integer $style    显示样式
     * @return	string
     */
    public function alipay_code($order, $style = 1)
    {
    	$pay_config = self::get_pay_config();
    	$seller_email = $pay_config['seller_mail'];
    	$partner = $pay_config['partner'];
    	$secret_key = $pay_config['secret_key'];
    	$service = $pay_config['service'];
    	
        $charset = 'utf-8';
        $extend_param = 'isv^sh22';

        $price = '0.01';  // 支付金额
        
        $parameter = array(
            'extend_param'      => $extend_param,
            'service'           => $service,
            'partner'           => $partner,
            '_input_charset'    => $charset,
            //'notify_url'        => 'http://lok.me/notify_log.php', 
		    'notify_url'        => C('WEB_HOST') . '/Pay_notify', 
            'return_url'        => C('WEB_HOST') . '/Pay_callback', 
            'subject'           => $order['order_sn'],
            'out_trade_no'      => $order['order_sn'] . $order['log_id'],
            'price'             => $order['order_amount'],
            'quantity'          => 1,
            'payment_type'      => 1,
            /* 物流信息 */
            'logistics_type'    => 'EXPRESS',
            'logistics_fee'     => 0,
            'logistics_payment' => 'BUYER_PAY',
            'seller_email'      => $seller_email
        );
        
        ksort($parameter);
        reset($parameter);
        
        $param = '';
        $sign  = '';
        
        foreach ($parameter AS $key => $val) {
            $param .= "$key=" . urlencode($val) . "&";
            $sign  .= "$key=$val&";
        }

        $param = substr($param, 0, -1);
        $sign  = substr($sign, 0, -1) . $secret_key;

//        echo $sign;
		if ($style == 1) {
			$button = '<input type="button" id="paySubmitBtn" class="ui-button ui-button-morange" onclick="window.open(\'https://mapi.alipay.com/gateway.do?'.$param. '&sign='.md5($sign).'&sign_type=MD5\')" value="立即支付" />';
		} 
		elseif ($style == 2) {
			$button = '<a href="javascript:void(0)" id="paySubmitBtn" class="ui-button ui-button-morange" onclick="window.open(\'https://mapi.alipay.com/gateway.do?'.$param. '&sign='.md5($sign).'&sign_type=MD5\')" />付款</a>';
		}elseif ($style == 3) {
			
			return 'https://mapi.alipay.com/gateway.do?'.$param. '&sign='.md5($sign).'&sign_type=MD5';
		}
		else {
			$button = '<input type="button" id="paySubmitBtn" class="ui-button ui-button-morange" onclick="window.open(\'https://mapi.alipay.com/gateway.do?'.$param. '&sign='.md5($sign).'&sign_type=MD5\')" value="立即支付" />';
		}
        return $button;
    }
    
    /**
     * 响应回调函数
     */
    public function respond() {
    	
    	if (!empty($_POST)) {
    		foreach ($_POST as $key => $val) {
    			$_GET[$key] = $val;
    		}
    	}
    	
    	$pay_config = self::get_pay_config();
        $seller_email = rawurldecode($_GET['seller_email']);
        $log_id = str_replace($_GET['subject'], '', $_GET['out_trade_no']);
        $log_id = trim($log_id);

        if (!check_money($log_id, $_GET['total_fee'])) {
        	echo $_GET['total_fee'];
            return false;
        }

        ksort($_GET);
        reset($_GET);

        $sign = '';
        foreach ($_GET AS $key=>$val) {
            if ($key != 'sign' && $key != 'sign_type' && $key != 'code' && $key != '_URL_')  { //_URL_为框架返回的PATHINFO参数，需要过滤 
                $sign .= "$key=$val&";
            }
        }
        $sign = substr($sign, 0, -1) . $pay_config['secret_key'];
        
        if (md5($sign) != $_GET['sign']) {
            return false;
        }
        if ($_GET['trade_status'] == 'WAIT_SELLER_SEND_GOODS') {
            order_paid($log_id, 2);
            return true;
        } elseif ($_GET['trade_status'] == 'TRADE_FINISHED') {
            order_paid($log_id);
            return true;
        } elseif ($_GET['trade_status'] == 'TRADE_SUCCESS') {
            order_paid($log_id, 2);
            return true;
        } else {
            return false;
        }
    }
    
    /**
     * 获取支付宝配置信息
     * @return array
     */
    private function get_pay_config() {
    	$Payment = M('payment');
    	$where['pay_code&enabled'] = array('alipay', '1', '_multi'=>true);
    	$alipay_info = $Payment->field('pay_fee,pay_config')->where($where)->find();
    	$pay_fee = intval($alipay_info['pay_fee']);
    	$pay_config = unserialize($alipay_info['pay_config']);
    	foreach ($pay_config as $key => $val) {
    		if ($val['name'] == 'alipay_account') { // 收款卖家EMAIL
    			$seller_email = trim($val['value']); 
    		}
    		if ($val['name'] == 'alipay_partner') {  // 支付宝合作PID
    			$partner = trim($val['value']);
    		}
    		if ($val['name'] == 'alipay_key') {   // 支付宝合作KEY
    			$secret_key = trim($val['value']);
    		}
    		if ($val['name'] == 'alipay_pay_method') {
    			if ($val['value'] == 0) { // 双接口
    				$service = 'trade_create_by_buyer';
    			} elseif ($val['value'] == 1) { // 担保交易
    				$service = 'create_partner_trade_by_buyer';
    			} elseif ($val['value'] == 2) {  // 即时到帐
    				$service = 'create_direct_pay_by_user';
    			}
    		}
    	}
    	return array('seller_mail' => $seller_email, 'partner' => $partner, 'secret_key' => $secret_key, 'service' => $service);
    }
}




